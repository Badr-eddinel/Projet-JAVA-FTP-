import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import java.net.InetAddress;
import java.net.Socket;
import java.net.URL;
import java.net.UnknownHostException;
import java.util.Iterator;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;

public class ChatController {

	@FXML
	private ResourceBundle resources;

	@FXML
	private URL location;

	@FXML
	private TextArea areaDiscussion;

	@FXML
	private TextField entreeAdresseIP;

	@FXML
	private TextField entreeMessage;

	@FXML
	private TextField entreePort;

	@FXML
	private TextField entreePseudo;

	@FXML
	private Label labelEtatConnexion;

	static InetAddress adr;
	static Socket socket;
	static OutputStream output;
	boolean connected;

	private Alert erreurConnexion;

	void pbConnexion() {
		erreurConnexion = new Alert(Alert.AlertType.ERROR);
		erreurConnexion.setContentText("Erreur à la connexion");
		erreurConnexion.showAndWait();
	}

	@FXML
	void actionBoutonConnexion(ActionEvent event) {
		if (!connected) {
			try {
				adr = InetAddress.getByName(entreeAdresseIP.getText());
			} catch (UnknownHostException e) {
				System.out.println("Erreur de récupération de l'addresse");
				pbConnexion();
				return;
			}

			try {
				socket = new Socket(adr, Integer.parseInt(entreePort.getText()));
			} catch (IOException e) {
				System.out.println("Erreur de création de la Socket");
				pbConnexion();
				return;
			} catch (NumberFormatException e) {
				pbConnexion();
				return;
			}
			
			try {
				output = socket.getOutputStream();
			} catch (IOException e) {
				System.out.println("Erreur de récupération du flux objet sortant");
				pbConnexion();
				return;
			}
			labelEtatConnexion.setText("Connecté");
			connected = true;
			
			Thread t = new Thread(() -> {
				listen();
			});
			t.start();
		}
	}

	@FXML
	void actionBoutonDeconnexion(ActionEvent event) {
		if (connected) {
			try {
				socket.close();
			} catch (IOException e) {
				System.out.println("Erreur de fermeture de la socket");
				e.printStackTrace();
			}
			labelEtatConnexion.setText("Déconnecté");
			connected = false;
		}
	}

	@FXML
	void actionBoutonEnvoyer(ActionEvent event) {
		if (connected) {
			String message = entreePseudo.getText() + " - " + entreeMessage.getText() + "\n";
			try {
				output.write(message.getBytes());
			} catch (IOException e) {
				System.out.println("Erreur d'envoi du message");
				e.printStackTrace();
				return;
			}
		}
	}

	@FXML
	void initialize() {

	}

	public void listen() {
		boolean stop = false; // Condition d'arrêt

		// Ouverture des flux entrant et sortant
		InputStream input = null;
		try {
			input = socket.getInputStream();
		} catch (IOException e) {
			System.out.println("Erreur de récupération du flux entrant");
			e.printStackTrace();
			return;
		}

		byte[] buffer = new byte[100]; // mettre plus grand si la chaine peut faire plus de 100 caractères

		while (!stop) {
			// Reception d'un message
			try {
				input.read(buffer);
			} catch (IOException e) {
				return;
			}
			String msg = new String(buffer);
			areaDiscussion.appendText(msg);
		}
	}

}
