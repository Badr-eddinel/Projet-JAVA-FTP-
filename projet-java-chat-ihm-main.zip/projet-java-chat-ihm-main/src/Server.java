import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

public class Server {
	static ServerSocket serverSocket;
	static Set<Socket> sockets = new HashSet<Socket>();

	public static void main(String[] args) {
		boolean stop = false; // Condition d'arrêt

		// Initialisation de la socket d'attente
		try {
			serverSocket = new ServerSocket(Integer.parseInt(args[0]));
		} catch (NumberFormatException e) {
			System.out.println("Erreur d'arguments (port n'est pas un nombre)");
			e.printStackTrace();
			System.exit(1);
		} catch (IOException e) {
			System.out.println("Erreur de création de la Socket");
			e.printStackTrace();
			System.exit(1);
		}

		while (stop != true) {
			System.out.println("En attente d'un client...");
			// Acceptation d'un client
			try {
				Socket s = serverSocket.accept();
				sockets.add(s);
				Thread t = new Thread(() -> {
					listen(s);
				});
				t.start();
				System.out.println("Nouveau client");
				System.out.println(s.getInetAddress().getHostAddress());
			} catch (IOException e) {
				System.out.println("Erreur d'acceptation du client");
				e.printStackTrace();
				System.exit(1);
			}

		}

	}

	public static void listen(Socket sock) {
		boolean stop = false; // Condition d'arrêt


		while (!stop) {
			byte[] buffer = new byte[100]; // mettre plus grand si la chaine peut faire plus de 100 caractères

			// Ouverture des flux entrant et sortant
			InputStream input = null;
			try {
				input = sock.getInputStream();
			} catch (IOException e) {
				System.out.println("Erreur de récupération du flux entrant");
				e.printStackTrace();
			}

			OutputStream output = null;
			
			// Reception d'un message
			try {
				input.read(buffer);
			} catch (IOException e) {
				sockets.remove(sock);
				stop = true;
				return;
			}
			String msg = new String(buffer);

			Iterator<Socket> it = sockets.iterator();
			while (it.hasNext()) {
				Socket s = it.next();
				// Renvoi du message à tous les clients
				try {
					output = s.getOutputStream();
				} catch (IOException e) {
					sockets.remove(s);
				}
				try {
					output.write(msg.getBytes());
				} catch (IOException e) {
					sockets.remove(s);
				}
			}
		}
	}
}
